function c_new = fun_set_tuning_parameter_MH(c_start, accept_ratio_prelim, acc_rate_min, acc_rate_max)


    assert(accept_ratio_prelim >= 0)
    assert(accept_ratio_prelim <= 1)

    if accept_ratio_prelim <= (0.5*acc_rate_min + 0.5*acc_rate_max)^5 
       c_new = c_start/5; % as in WWZ

    elseif (accept_ratio_prelim > (0.5*acc_rate_min + 0.5*acc_rate_max)^5 && accept_ratio_prelim < (0.5*acc_rate_min + 0.5*acc_rate_max)^(1/5)) 
       c_new = c_start*log(0.5*acc_rate_min + 0.5*acc_rate_max)/log(accept_ratio_prelim);

    elseif (accept_ratio_prelim >= (0.5*acc_rate_min + 0.5*acc_rate_max)^(1/5)) 
       c_new = c_start*5; % as in WWZ

    else
        stop
    end 
                
end