function lambda_allstages = fun_set_tempering_schedule(tempering_schedule,H_dsmh,param_tempering)


    if tempering_schedule == 1 

        lambda_tempering = param_tempering;

        lambda_allstages(1) = 0;
        for i = 2:H_dsmh+1
            lambda_allstages(i) = exp((H_dsmh-(i-1))/(H_dsmh-1)*log(lambda_tempering));
        end 
    
    elseif tempering_schedule == 2 

        lambda_tempering = gamma_tempering;

        lambda_allstages(1) = 0;
        for i = 2:H_dsmh+1
            lambda_allstages(i) = ((i-1)/(H_dsmh+1-1))^gamma_tempering;
        end 
    
    elseif tempering_schedule == 3

        lambda_tempering = gamma_tempering;

        lambda_allstages(1) = 0;
        for i = 2:H_dsmh+1
            lambda_allstages(i) = 2 - exp(log(2)*((H_dsmh-i+1)/H_dsmh)^gamma_tempering);
        end 

    else
        error('Tempering schedule not selected')
    end 

end