function [logLik_levels_vec,striations,striations_numbelements] = fun_striations(draw_previous,draw_previous_loglik,M_dsmh,num_param)


    % limit the analysis to the values that are plausible  
    step1 = (draw_previous_loglik~=Inf).*(draw_previous_loglik~=-Inf).*(isnan(draw_previous_loglik)==0);
    
    
    NG = size(draw_previous,2);
    NG_sub = sum(step1);
    if NG_sub == NG
    else
        disp(['  (computation of striations drops ', num2str(100*(NG-NG_sub)/(NG)) '% of the observations, +Inf, -Inf or NaN) '])
    end
    
    % compute striations
    logLik_levels_vec       = zeros(M_dsmh+1,1);
    striations              = zeros(num_param,NG_sub,M_dsmh);
    striations_numbelements = zeros(M_dsmh,1);

    
    draw_previous_sub        = draw_previous(:,step1==1);
    draw_previous_loglik_sub = draw_previous_loglik(step1==1);
    
    interval_vec = floor([1:1:M_dsmh]*NG_sub/M_dsmh);
    
    [draw_previous_loglik_sub_sorted, order_sorted] = sort(draw_previous_loglik_sub);
    
    draw_previous_sub_sorted = draw_previous_sub(:,order_sorted);
    
    logLik_levels_vec(1) = -Inf; 
    step = interval_vec(1);
    logLik_levels_vec(2) = draw_previous_loglik_sub_sorted(step);
    striations(:,1:step,1) = draw_previous_sub_sorted(:,1:step);
    striations_numbelements(1) = step;

   
    for stri = 2:M_dsmh
        
        step1 = interval_vec(stri-1);
        step2 = interval_vec(stri);
        logLik_levels_vec(stri+1) = draw_previous_loglik_sub_sorted(step2);
        striations(:,1:step2-step1,stri) = draw_previous_sub_sorted(:,step1+1:step2);
        striations_numbelements(stri) = step2-step1;
       
    end 
    logLik_levels_vec(M_dsmh+1) = Inf;
    
    
end
