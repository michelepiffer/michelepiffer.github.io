function [tempering_scale_thisstage, calib_tempering_iter_used, calib_tempering_diagnostics] = ...
            fun_calibrate_tempering(draw_previous_pdfintroduce_log, draw_previous_pdfdrop_log, tempering_scale_laststage, ESSrelative_min, ESSrelative_max)


    disp('Computing tempering parameter')

    max_steps = 0.01;
    
    tempering_scale_min = tempering_scale_laststage;
    tempering_scale_max = 1;
    
    tempering_scale_thisstage_temp = tempering_scale_min + min(max_steps, (tempering_scale_max-tempering_scale_min) );
    
    acceptable = 0;
    iter       = 0;
    
    calib_tempering_diagnostics = [];
    
    ESSrelative_mean = (0.5*ESSrelative_min + 0.5*ESSrelative_max);
    
    try_jump_to_one = 1;
    tempering_scale_thisstage_temp2 = 1;
    ESSrelative_temp2 = 0;
        
    while acceptable < 1
        
        iter = iter + 1;
        weights_tilde_log = (tempering_scale_thisstage_temp-tempering_scale_laststage)*draw_previous_pdfintroduce_log + ...
                          - (tempering_scale_thisstage_temp-tempering_scale_laststage)*draw_previous_pdfdrop_log;
      
        
        [~, ~, ~, ESSrelative] = fun_normalize_weigths(weights_tilde_log);  
                    
        calib_tempering_diagnostics = [calib_tempering_diagnostics, [tempering_scale_thisstage_temp; ESSrelative]];
        
            
        disp(['  iter = ', num2str(iter,3) ' ,  lambda = ', num2str(tempering_scale_thisstage_temp,3) ' ,  ESSrel = ', num2str(ESSrelative,4) ' ,  bounds: [',  num2str(ESSrelative_min,2) ', ', num2str(ESSrelative_max,2) ']'])
            


            if (ESSrelative >= ESSrelative_min && ESSrelative <= ESSrelative_max) || (ESSrelative >= ESSrelative_min && tempering_scale_thisstage_temp == 1  )
                acceptable = 1;
                tempering_scale_thisstage = tempering_scale_thisstage_temp;  
                calib_tempering_iter_used = iter;

                
            else

                    if  ESSrelative <= ESSrelative_min  % decrease tempering
                        
                       tempering_scale_max = tempering_scale_thisstage_temp;
                        
                       tempering_scale_thisstage_temp = tempering_scale_min + (tempering_scale_thisstage_temp-tempering_scale_min)*(ESSrelative/ESSrelative_mean);

                    elseif ESSrelative >= ESSrelative_max % increase tempering
                        
                       tempering_scale_min = tempering_scale_thisstage_temp;

                        
                       if (tempering_scale_thisstage_temp > 0.8 && try_jump_to_one == 1 )% try to jump to 1
                           tempering_scale_thisstage_temp2 = tempering_scale_thisstage_temp; % save, in case 1 does not satisfy and must continue with attempts
                           ESSrelative_temp2               = ESSrelative;
                           
                           tempering_scale_thisstage_temp = 1;
                           try_jump_to_one = 0; % so that if 1 did not work, it does not try it again 
                       else
                           tempering_scale_thisstage_temp = tempering_scale_max - (tempering_scale_max-  min(tempering_scale_thisstage_temp2,tempering_scale_thisstage_temp)  )*(ESSrelative_mean/max(ESSrelative_temp2,ESSrelative));%  min(1,tempering_scale_thisstage_temp*3);
                       end

                    else
                        stop
                    end 

                    assert( tempering_scale_thisstage_temp > tempering_scale_laststage )
                    assert( tempering_scale_thisstage_temp <= 1 )

            end
            
            
          if iter > 100
             stop_some_problem 
          end
    end
       
end