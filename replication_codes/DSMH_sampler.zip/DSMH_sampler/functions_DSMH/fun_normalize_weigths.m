function [weights, weights_admit, ESS, ESSrelative] = fun_normalize_weigths(weights_tilde_log)

    N_step = length(weights_tilde_log);
    
    
    % check which of the log weigths are admissible
    weights_admit = ones(N_step,1);
    weights_admit(isnan(weights_tilde_log)== 1) = 0;
    weights_admit(weights_tilde_log == Inf)  = 0;
    weights_admit(weights_tilde_log == -Inf) = 0; 
    N_step_admit = sum(weights_admit);
    
    if (N_step-N_step_admit)/N_step > 0.30 
        disp(['  (normalization of weigths drops  ', num2str(100*(N_step-N_step_admit)/N_step), '% of the observations, +Inf, -Inf or NaN) '])
    else
    end
    
    % rescale. it won't affect the normalized weigths
    step_rescale = max(weights_tilde_log(weights_admit==1)) ;
    
    weights_tilde_log_scaled = weights_tilde_log - step_rescale; 
    
    % convert log weigths into weigths: values below a certain negative threshold will become zeros
    weights_tilde = exp(weights_tilde_log_scaled);
    weights_tilde(weights_admit==0) = NaN;
    
    
    % check that no new unadmissible weigths arises after taking exp
    weights_admit2 = ones(N_step,1);
    weights_admit2(isnan(weights_tilde)== 1) = 0;
    weights_admit2(weights_tilde == Inf)  = 0;
    weights_admit2(weights_tilde == -Inf) = 0;
    
    assert( sum(abs(weights_admit2 - weights_admit)) == 0)
    
    
    % compute normalized weigths, normalizing only by the admissible weigths
    weights = weights_tilde/sum(weights_tilde(weights_admit==1));
    weights(weights_admit==0) = 0;
    
    assert( abs( sum(weights(weights_admit==1))- 1) < 0.00001 )
    
    
    ESS  = 1/sum(weights(weights_admit==1).^2);  
    % =1     if perfectly unbalanced, =NG if perfectly balanced   
    % =1/length(weigths)  if perfectly unbalanced, =1 if perfectly balanced 
    
    
    ESSrelative = ESS/N_step_admit;       % =1/NG  if perfectly unbalanced, =1 if perfectly balanced 
    
    weights_tilde_log_temp = weights_tilde_log;
    weights_tilde_log_temp(weights_admit==0) = NaN;
    weights_tilde_log_scaled_temp = weights_tilde_log_scaled;
    weights_tilde_log_scaled_temp(weights_admit==0) = NaN;
    
                
end
