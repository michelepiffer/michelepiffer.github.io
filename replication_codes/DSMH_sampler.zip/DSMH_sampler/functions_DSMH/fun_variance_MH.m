function Omega = fun_variance_MH(draw_previous, weights, num_param, weights_admit)

    % only use the admissible draws
    draw_previous_sub = draw_previous(:,weights_admit==1);
    weights_sub       = weights(weights_admit==1);
    NG_sub            = length(weights_sub);
    
    assert( abs(sum(weights_sub)-1) < 0.00001) 
    
    mu_step = sum(kron(ones(num_param,1), weights_sub').*draw_previous_sub,2);
    
    variance_MH = zeros(num_param,num_param);
    for i = 1:NG_sub
        variance_MH = variance_MH +  weights_sub(i)*draw_previous_sub(:,i)*draw_previous_sub(:,i)';
    end 
    Omega = variance_MH - mu_step*mu_step';
        
end
