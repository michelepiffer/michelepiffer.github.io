function [target_function, logpdf_stays, logpdf_introduce, logpdf_drop] = fun_target_function(theta_free, tempering_scale,STR)

 
    v2struct(STR)
    
    % Function that stays in the target function along stages                                  
    logpdf_stays = fun_logpdf_stay(theta_free);
    
    
    % Function that is introduced in the target function along stages                                  
    logpdf_introduce = fun_logpdf_introduce(theta_free);
                            
    % Function that is dropped from the target function along stages                                      
    logpdf_drop = fun_logpdf_drop(theta_free);
    
    
    target_function = logpdf_stays + tempering_scale*logpdf_introduce + (1-tempering_scale)*logpdf_drop;

end