function [theta_fullchain, accept_howmany, accept_howmany_ratio] = ...
                        fun_MetropHast(theta_old,c,iterations,tempering_scale,Omega_chol,STR)


    v2struct(STR)

    theta_n = length(theta_old);
    
    theta_fullchain = NaN*ones(theta_n,iterations);
    
    check_accepted = zeros(iterations,1);
    prob_accept    = NaN*ones(iterations,1);
      
    step_udistrib = rand(iterations,1);
    
    [target_old, ~, ~, ~] = fun_target_function(theta_old, tempering_scale, STR);

    
    for i = 1:iterations
        
        acceptable = 1>2; 
        attempts   = 0;
        
        while acceptable==0 && attempts <=200
                        
            theta_shocks = mvnrnd(zeros(theta_n,1), c*(Omega_chol*Omega_chol'), 1)';
            theta_new    = theta_old +  theta_shocks;
            acceptable   = fun_acceptable(theta_new);
            attempts     = attempts + 1;

        end

        [target_new, ~, ~, ~] = fun_target_function(theta_new, tempering_scale, STR);


        assert( isnan(target_new) == 0 )              

        step2 = exp(target_new - target_old);
        prob_accept(i) = min(step2,1);

        if step_udistrib(i) < prob_accept(i)
           theta_old  = theta_new;
           target_old = target_new;
           check_accepted(i) = 1; % all accepted draws are counted, irrespectively of whether a burn in was passed or not
        else
        end 
       
        theta_fullchain(:,i) = theta_old;
       
    end
    
    accept_howmany = sum(check_accepted);
    accept_howmany_ratio = accept_howmany/iterations;
    
end
