%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
% Routine to run the Dynamic Striated Metropolis Hastings algorithm % 
% by Waggoner_Wu_Zha (JoE 2016)                                     %
% Codes by Martin Bruns and Michele Piffer in their QE (2023) paper %
% This version: May 2026                                            %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This file: shows figures and saves the file with the draws

clc
close all


%% Some preliminary things

%%% Colors

grey    = [0.8,0.8,0.8]; 
grey2   = [0.6,0.6,0.6];
grey3   = [0.7,0.7,0.7];
grey4   = [0.5,0.5,0.5];
blue    = [0.25,0.3,0.8];
blue2   = [0.3,0.6,0.9];
red     = [0.6,0.1,0.2];
red2    = [0.65,0.1,0.2];
red3    = [0.7,0.1,0.2];
orange  = [0.9290, 0.6940, 0.1250];
orange2 = [240 100 10]/256;
purple  = [0.4940, 0.1840, 0.5560];
purple2 = [0.5140, 0.2040, 0.6060];
black   = [0, 0, 0];
olivegreen = [0.345 0.368 0.11];
green = [0.13, 0.55, 0.13];

color_start = red3;
color_end   = blue2;

%%% Dimensions of the figures

figsize_2 = [0 0 1200*.7 700*.7];


%% Figure with progression for theta

nfig = nfig + 1;
figure(nfig)
for i = 1:theta_n   

    subplot(fig_x,fig_y,i)
    hold on; grid on;

    legend_index = [];
    legend_names = [];

    %%% Plot starting distribution
    show_step = squeeze(theta_starting_draws(i,:));
    pd = fitdist(show_step','kernel'); 
    x_values = linspace(min(show_step), max(show_step), 7000);
    y = pdf(pd,x_values);
    index = plot(x_values,y, 'Linestyle', '--', 'Color', color_start, 'Linewidth', 2); 

    legend_index = [legend_index, index];
    legend_names = [legend_names; cellstr('Starting distribution')];

    %%% Plot distribution from this stage
    for j = 1:size(theta_intermid_draws,3)
        show_step = squeeze(theta_intermid_draws(i,:,j));
        pd = fitdist(show_step','kernel'); 
        x_values = linspace(min(show_step), max(show_step), 7000);
        y = pdf(pd,x_values);

        temp       = j/(size(theta_intermid_draws,3)+2);
        color_temp = temp*color_end + (1-temp)*color_start;

        index = plot(x_values,y, 'Color', color_temp, 'Linewidth', 1); 
        if j == 1
            legend_index = [legend_index, index];
            legend_names = [legend_names; cellstr('Intermediate distributions')];
        end
    end

    %%% Plot final distribution
    show_step = squeeze(theta_ending_draws(i,:));
    pd = fitdist(show_step','kernel'); 
    x_values = linspace(min(show_step), max(show_step), 7000);
    y = pdf(pd,x_values);
    index = plot(x_values,y, 'Linestyle', '-', 'Color', color_end, 'Linewidth', 3); 

    legend_index = [legend_index, index];
    legend_names = [legend_names; cellstr('Final distribution')];


    %%% Additional items for the figure
    set(gca,'box','off')
    title(theta_names(i), 'Interpreter', 'latex')
    set(gca, 'YTick', [0]) % eliminates ticks on y axis, since not meaningful        
    if i == 1
        legend(legend_index, legend_names, 'Location', 'best', 'Interpreter', 'latex', 'AutoUpdate', 'off'); % legend('boxoff') 
    end
end
set(gcf,'Position',figsize_1)
movegui('west')
set(gcf, 'PaperPositionMode', 'auto'); 


%% Figure for the progression of the sampler

if isnan(H_dsmh)
    axis_diagn = [1:1:H_dsmh_found];
else
    axis_diagn = [1:1:H_dsmh];
end

nfig = nfig + 1;
figure(nfig)

    subplot(3,1,1)
    hold on; grid on;

plot(axis_diagn, lambda_allstages_show, '- b', 'Linewidth', 1); 
plot(axis_diagn, lambda_allstages_show, '. b', 'Markersize', 10); 
plot(i_stage-1,tempering_scale_thisstage, 'o r'); 

%%% Additional items for the figure
ylim([0 1])        
set(gca, 'XTick', axis_diagn) 
title('tempering parameter', 'Interpreter', 'latex')
set(gca,'box','off')

    subplot(3,1,2)
    hold on; grid on;

plot(axis_diagn, ESSrelative_allstages_show, '- b', 'Linewidth', 1); 
plot(axis_diagn, ESSrelative_allstages_show, '. b', 'Markersize', 10); 
if isnan(H_dsmh)
    plot(axis_diagn, ESSrelative_min*ones(length(ESSrelative_allstages_show),1), '-- r')
    plot(axis_diagn, ESSrelative_max*ones(length(ESSrelative_allstages_show),1), '-- r')        
end

%%% Additional items for the figure
ylim([0 1])        
set(gca, 'XTick', axis_diagn) 
title('relative ESS', 'Interpreter', 'latex')
set(gca,'box','off')

    subplot(3,1,3)
    hold on; grid on;

plot(axis_diagn, accept_ratio_allstages_show, '- b', 'Linewidth', 1); 
plot(axis_diagn, accept_ratio_allstages_show, '. b', 'Markersize', 10); 
plot(axis_diagn, alpha_0*ones(length(accept_ratio_allstages_show),1), '-- r')
plot(axis_diagn, alpha_1*ones(length(accept_ratio_allstages_show),1), '-- r')          


%%% Additional items for the figure
ylim([0 1])        
title('acceptance ratio in composite MH', 'Interpreter', 'latex')
set(gca, 'XTick', axis_diagn) 
set(gca,'box','off')

set(gcf, 'PaperPositionMode', 'auto');          
set(gcf,'Position',figsize_2)
movegui('southeast')


%% If needed, save the output

save('OutputDSMH.mat', 'theta_ending_draws', 'n_draws');

