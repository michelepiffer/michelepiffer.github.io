%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
% Routine to run the Dynamic Striated Metropolis Hastings algorithm % 
% by Waggoner_Wu_Zha (JoE 2016)                                     %
% Codes by Martin Bruns and Michele Piffer in their QE (2023) paper %
% This version: May 2026                                            %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This file: runs the DSMH sampler


clc
clearvars -except fun_logpdf_stay ...
                  fun_logpdf_introduce ...
                  fun_logpdf_drop ...
                  fun_theta_to_out ...
                  fun_acceptable ...
                  theta_names ...
                  theta_n ...
                  theta_starting_draws ...
                  fig_x ...
                  fig_y
close all


%% THINGS TO SELECT 1: if the number of stages is pre-selected or selected by the algorithm

%%% Comment in if Option 1: pre-select the number of stages

% H_dsmh = 6; % Tempering of the likelihood: number of stages (WWZ use 50)
% 
% tempering_schedule = 1; % as in WWZ. Tempering of the likelihood: first element of the vector fixing the degree of tempering (WWZ use 1/(10*k*T))
% param_tempering = 0.05; 
% 
% % tempering_schedule = 2;  % Baseline: as in HS 
% % param_tempering = 2; 


%%% Comment in if Option 2: let the algorithm select the number of stages

H_dsmh = NaN; % Like this, it will be selected by the algorithm depending on the progression
ESSrelative_min = 0.85;
ESSrelative_max = 0.98; 


%% THINGS TO SELECT 2: Parameters for the specification of the sampler

G_dsmh   = 4;     % Number of simulations: number of groups (WWZ use 100) --> should be a multiple of computing cores 
N_dsmh   = 2000;  % 4000 Number of simulations: number of saved observations within group (WWZ use 2000)
K_dsmh   = 2000;  % Number of simulations: number of preliminary draws within each G to set the tuning parameter (WWZ use 500)
M_dsmh   = 10;    % Striations: number of groups created (WWZ use 50)
Tau_dsmh = 1;     % The "thinning factor", save only draws that are multiple of Tau (WWZ use 50)
      
alpha_0   = 0.20;   % Lower bound of the acceptance ratio (WWZ use 0.20)
alpha_1   = 0.30;   % Upper bound of the acceptance ratio (WWZ use 0.30)

if ~isnan(H_dsmh) 
   H_dsmh_step = H_dsmh;
else
   H_dsmh_step     = 1; 
end


introduce_Tau_progressively = 0;
Tau_dsmh_start = NaN;


%% THINGS TO SELECT 3: if shows intermediate figures of the distribution on theta, or only first and last stage

show_indermidfig_theta = 1; % 0 or 1


%% THINGS TO SELECT 4: if shows diagnostics on the performance of the sampler or not 

show_indermidfig_diagnostic = 0; % 0 or 1


%% Additional preliminary steps

%%% Switch off warning signs

warning('off','MATLAB:nearlySingularMatrix')


%%% Add path to functions 
addpath('functions_DSMH')


%%% Dimensions of the figures

figsize_1 = [0 0 1200*.7 700*.7];


%%% Counter for the figures

nfig = 0;


%%% Set the seed number

rng(100)



%% Prepare the DSMH

lambda_allstages             = NaN*ones(H_dsmh_step+1,1);
lambda_diagnostics_allstages = NaN*ones(2,100,H_dsmh_step+1);


%%% If pre-select progression of stages, set the full vector of lambda
if ~isnan(H_dsmh) 
    lambda_allstages = fun_set_tempering_schedule(tempering_schedule,H_dsmh,param_tempering);
end

%%% Select the starting value of the tuning parameters and acceptance ratios
c_dsmh_start = 3;
c_dsmh_allstages = NaN*ones(H_dsmh_step,1);

% to select if we pick from striations or not
p_dsmh      = 0.10/Tau_dsmh; % use the upperbound for Tau even if we introduce it progressively in the code


%%% Check that we have enough starting draws

if size(theta_starting_draws,2) < N_dsmh*G_dsmh
    error('Not enough initial draws for theta were provided, given the selecged N and G for the algorithm')
else
    theta_starting_draws = theta_starting_draws(:,1:N_dsmh*G_dsmh);
end


%% Add the key functions in a structure

STR.fun_logpdf_stay      = fun_logpdf_stay;
STR.fun_logpdf_introduce = fun_logpdf_introduce;
STR.fun_logpdf_drop      = fun_logpdf_drop;
STR.fun_theta_to_out     = fun_theta_to_out;
STR.fun_acceptable       = fun_acceptable;


%% Initial figure

nfig = nfig + 1;
figure(nfig)
for i = 1:theta_n   

    subplot(fig_x,fig_y,i)
    hold on; grid on;

    legend_index = [];
    legend_names = [];

    %%% Plot starting distribution
    show_step = squeeze(theta_starting_draws(i,:));
    pd = fitdist(show_step','kernel'); 
    x_values = linspace(min(show_step), max(show_step), 7000);
    y = pdf(pd,x_values);
    index = plot(x_values,y, 'Linestyle', '--', 'Color', 'r', 'Linewidth', 1); hold on

    legend_index = [legend_index, index];
    legend_names = [legend_names; cellstr('Starting distribution')];

    %%% Additional items for the figure
    set(gca,'box','off')
    title(theta_names(i), 'Interpreter', 'latex')
    set(gca, 'YTick', [0]) % eliminates ticks on y axis, since not meaningful        

end
set(gcf,'Position',figsize_1)
movegui('west')
set(gcf, 'PaperPositionMode', 'auto'); 


%% Prepare the sampler
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %
%  Sampler at stage i_stage = 1: target function is the prior (NONO):  prepare for the continuation of the code  %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %

tic_fullalgor = tic; % full algorithm

disp('Computing initial functions on the draws starting the algorithm')

% Rehsape outpout elements for compatibility with parfor loop
draw_previous                  = reshape(theta_starting_draws,theta_n,N_dsmh,G_dsmh);
draw_previous_pdfstay_log      = zeros(N_dsmh,G_dsmh);  
draw_previous_pdfintroduce_log = zeros(N_dsmh,G_dsmh);
draw_previous_pdfdrop_log      = zeros(N_dsmh,G_dsmh); 
draw_previous_loglik           = zeros(N_dsmh,G_dsmh); 


tic_computeinitialfunctions = tic; % preliminary computations



% parfor i_group = 1:G_dsmh 
for i_group = 1:G_dsmh 
  
    for i_n = 1:N_dsmh
        
        theta_free = draw_previous(:,i_n,i_group);
        
        draw_previous_pdfintroduce_log(i_n,i_group) = fun_logpdf_introduce(theta_free);
        draw_previous_pdfdrop_log(i_n,i_group)      = fun_logpdf_drop(theta_free);
        draw_previous_loglik(i_n,i_group)           = fun_logpdf_introduce(theta_free); % WHY THE LIKELIHOOD? NOT JUST INTRODUCE DROP AND STAY??

    end
    
end
second_taken_computeinitialfunctions = toc(tic_computeinitialfunctions); % preliminary computations
disp([' computing initial functions took (h-m-s) ', num2str(fix(mod(second_taken_computeinitialfunctions, [0, 3600, 60]) ./ [3600, 60, 1])) ])


%% Reshape output elements

draw_previous                  = reshape(theta_starting_draws, theta_n, N_dsmh*G_dsmh);
draw_previous_pdfstay_log      = reshape(draw_previous_pdfstay_log,      N_dsmh*G_dsmh,1);  
draw_previous_pdfintroduce_log = reshape(draw_previous_pdfintroduce_log, N_dsmh*G_dsmh,1);
draw_previous_pdfdrop_log      = reshape(draw_previous_pdfdrop_log,      N_dsmh*G_dsmh,1); 
draw_previous_loglik           = reshape(draw_previous_loglik,           N_dsmh*G_dsmh,1); 

i_stage = 1;
if isnan(H_dsmh) 

    tempering_scale_laststage = 0;                
    [tempering_scale_thisstage, calib_tempering_iter_used, calib_tempering_diagnostics] = fun_calibrate_tempering(draw_previous_pdfintroduce_log, draw_previous_pdfdrop_log, tempering_scale_laststage, ESSrelative_min, ESSrelative_max);
    lambda_allstages(i_stage)   = tempering_scale_laststage;
    lambda_allstages(i_stage+1) = tempering_scale_thisstage;
    lambda_diagnostics_allstages(:,1:calib_tempering_iter_used,i_stage+1) = calib_tempering_diagnostics;

else
    tempering_scale_laststage = lambda_allstages(i_stage);
    tempering_scale_thisstage = lambda_allstages(i_stage+1);
end
draw_previous_weights_tilde_log = (tempering_scale_thisstage - tempering_scale_laststage)*draw_previous_pdfintroduce_log + ...
                                - (tempering_scale_thisstage - tempering_scale_laststage)*draw_previous_pdfdrop_log;
                             

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %
% Sampler starting from stage i = 2: start using tempered functions %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %

ESSrelative_allstages       = NaN*ones(H_dsmh_step,1);
c_dsmh_allstages_iterneeded = NaN*ones(H_dsmh_step,1);
accept_ratio_allstages      = NaN*ones(H_dsmh_step,1); 
draws_allstages             = NaN*ones(theta_n,N_dsmh*G_dsmh,H_dsmh_step);
N_dsmh_allstages            = NaN*ones(H_dsmh_step,1);
subloop_allstages           = NaN*ones(H_dsmh_step,1);
seconds_taken_compositeMHs_allstages = NaN*ones(H_dsmh_step,1);

last_loop_reached = 0;    
while last_loop_reached == 0
   
    i_stage = i_stage + 1;
    
    if isnan(H_dsmh) == 1 && i_stage+1 >= H_dsmh_step
        lambda_allstages             = cat(1,lambda_allstages, NaN);
        c_dsmh_allstages             = cat(1,c_dsmh_allstages, NaN);
        ESSrelative_allstages        = cat(1,ESSrelative_allstages, NaN);
        c_dsmh_allstages_iterneeded  = cat(1,c_dsmh_allstages_iterneeded, NaN);
        accept_ratio_allstages       = cat(1,accept_ratio_allstages, NaN);
        draws_allstages              = cat(3, draws_allstages, NaN*ones(theta_n,size(draws_allstages,2)) );
        N_dsmh_allstages             = cat(1, N_dsmh_allstages, NaN);
        subloop_allstages            = cat(1, subloop_allstages, NaN);
        seconds_taken_compositeMHs_allstages = cat(1, seconds_taken_compositeMHs_allstages, NaN);
        
    end
    
    
    disp(' ')
    disp('=======================')
    disp(['Starting stage ', num2str(i_stage-1) ' out of ', num2str(H_dsmh) ' (tempering from ', num2str(tempering_scale_laststage,10) ' to ',  num2str(tempering_scale_thisstage,10) ')'])
    pause(2)
    

    % Compute striations of draws from previous stage %  
    [logLik_levels_vec,striations,striations_numbelements] = fun_striations(draw_previous,draw_previous_pdfintroduce_log,M_dsmh,theta_n);
    
    
    % Compute weigths and ESS only using draws that are available, i.e. not NaN. Implies that prior is such that V_phi_star is always invertible
    [weights, weights_admit, ~, ESSrelative] = fun_normalize_weigths(draw_previous_weights_tilde_log);
    ESSrelative_allstages(i_stage-1) = ESSrelative;   
    disp(['ESSrelative is  ', num2str(ESSrelative) ])
    
    
    % Compute variance used for the MH component
    Omega = fun_variance_MH(draw_previous, weights, theta_n, weights_admit);  
    

    [Step1, Step2] = eig(Omega);            
    Omega_chol = Step1*Step2^0.5;
    Omega_chol = real(Omega_chol); 
    
            
    % Set the tuning parameter c %
    disp('Computing tuning parameter')
    tic_computetuning = tic; % compute tuning parameter
    accept_ratio_prelim = 0;
    iter = 0;
    while  accept_ratio_prelim < alpha_0 || accept_ratio_prelim > alpha_1
        
        i_select_allG  = fun_discretesample(weights, G_dsmh);
        theta_old_allG = draw_previous(:,i_select_allG); 
    
        accept_howmany_allG_fortuning = zeros(G_dsmh,1);
        iter       = iter + 1;
        iterations = K_dsmh;    
    
%         parfor i_group = 1:G_dsmh            
        for i_group = 1:G_dsmh            

            [~, accept_howmany, ~] = fun_MetropHast(theta_old_allG(:,i_group),c_dsmh_start,iterations,tempering_scale_thisstage,Omega_chol,STR);              
            
            accept_howmany_allG_fortuning(i_group) = accept_howmany;      
        end

        accept_ratio_prelim = sum(accept_howmany_allG_fortuning)/(K_dsmh*G_dsmh);


        disp([' iter = ', num2str(iter,2) ' ,  c = ', num2str(c_dsmh_start,3) ' ,  accept = ', num2str(accept_ratio_prelim,4) ' ,  bounds: [',  num2str(alpha_0,2) ', ', num2str(alpha_1,2) ']'])


        if accept_ratio_prelim >= alpha_0 && accept_ratio_prelim <= alpha_1
            c_dsmh_allstages(i_stage-1) = c_dsmh_start; 
        else
            c_dsmh_start = fun_set_tuning_parameter_MH(c_dsmh_start, accept_ratio_prelim, alpha_0, alpha_1);      
        end  

        if iter > 50
            disp(['STOP: search of c is taking too long. We are at stage = ', num2str(i_stage)])
            STOPPPP
        end
            
    end
    seconds_taken_computetuning = toc(tic_computetuning); % compute tuning parameter
    disp([' computing tuning parameter took (h-m-s) ', num2str(fix(mod(seconds_taken_computetuning, [0, 3600, 60]) ./ [3600, 60, 1])) ])
    c_dsmh_allstages_iterneeded(i_stage-1) = iter;


    % Start the algorithm %
    disp('Start the composite Metropolis-Hastings') 
    tic_compositeMH = tic; % composite MH

    
    draw_previous_tot                    = [];
    logpdf_stays_export_previous_tot     = [];
    logpdf_introduce_export_previous_tot = [];
    logpdf_drop_export_previous_tot      = [];
    lik_log_export_previous_tot          = [];
    check_accepted_tot                   = 0;

    subloop = 1;

        if subloop == 1

            % Prepare variables needed in the loops      
            theta_old_allG = draw_previous(:,i_select_allG); 
            target_function_old_allG  = NaN*ones(G_dsmh,1);
            logpdf_stays_old_allG     = NaN*ones(G_dsmh,1);
            logpdf_introduce_old_allG = NaN*ones(G_dsmh,1);
            logpdf_drop_old_allG      = NaN*ones(G_dsmh,1);
            lik_log_export_old_allG   = NaN*ones(G_dsmh,1);
            for i_group = 1:G_dsmh

                [target_function, logpdf_stays, logpdf_introduce, logpdf_drop] = fun_target_function(theta_old_allG(:,i_group), tempering_scale_thisstage, STR);

                target_function_old_allG(i_group)  = target_function;
                logpdf_stays_old_allG(i_group)     = logpdf_stays;
                logpdf_introduce_old_allG(i_group) = logpdf_introduce;
                logpdf_drop_old_allG(i_group)      = logpdf_drop;
                lik_log_export_old_allG(i_group)   = logpdf_introduce; 

            end 

            if i_stage == 2
                N_dsmh_subloop = N_dsmh;
            else
%                     N_dsmh_subloop = round(0.8*N_dsmh_allstages(i_stage-2)); % so that it can also decrease
                N_dsmh_subloop = N_dsmh_allstages(i_stage-2); % so that it never decreases
            end
            N_dsmh_thisstage = N_dsmh_subloop;
        end

        if introduce_Tau_progressively == 0
            Tau_dsmh_subloop = Tau_dsmh;
        else
            Tau_dsmh_subloop = Tau_dsmh_start + round(tempering_scale_thisstage*(Tau_dsmh-Tau_dsmh_start));
        end
        Tau_veckeep_subloop = [Tau_dsmh_subloop : Tau_dsmh_subloop : N_dsmh_subloop*Tau_dsmh_subloop]';

        draw_next_cell             = cell(G_dsmh,1);
        logpdf_stays_next_allG     = NaN*ones(N_dsmh_subloop,G_dsmh);
        logpdf_introduce_next_allG = NaN*ones(N_dsmh_subloop,G_dsmh);
        logpdf_drop_next_allG      = NaN*ones(N_dsmh_subloop,G_dsmh);
        lik_log_export_next_allG   = NaN*ones(N_dsmh_subloop,G_dsmh);  

        MHprob_vec_allG           = rand(N_dsmh_subloop*Tau_dsmh_subloop,G_dsmh);
        step_udistrib_allG        = rand(N_dsmh_subloop*Tau_dsmh_subloop,G_dsmh);
        check_accepted_allG       = zeros(G_dsmh,1);
        theta_new_allG            = NaN*ones(theta_n,G_dsmh);
        target_function_new_allG  = NaN*ones(G_dsmh,1);
        logpdf_stays_new_allG     = NaN*ones(G_dsmh,1);
        logpdf_introduce_new_allG = NaN*ones(G_dsmh,1);
        logpdf_drop_new_allG      = NaN*ones(G_dsmh,1);
        lik_log_export_new_allG   = NaN*ones(G_dsmh,1);


                % parfor i_group = 1:G_dsmh     
                for i_group = 1:G_dsmh 
    
                        % Create temporary group-specific output arrays
                        draw_next_temp                      = NaN*ones(theta_n,N_dsmh_subloop*length(Tau_dsmh_subloop));
                        logpdf_stays_next_igroup_temp       = NaN*ones(length(Tau_dsmh_subloop),1);
                        logpdf_introduce_next_igroup_temp   = NaN*ones(length(Tau_dsmh_subloop),1);
                        logpdf_drop_next_igroup_temp        = NaN*ones(length(Tau_dsmh_subloop),1);
                        lik_log_export_next_igroup_temp     = NaN*ones(length(Tau_dsmh_subloop),1);
                        have_tau = 0;
                        
                        
                                              
                        for i_ntau = 1:N_dsmh_subloop*Tau_dsmh_subloop

                                if MHprob_vec_allG(i_ntau,i_group) >= p_dsmh 
                                    
                                        % run the MH
                                        acceptable = 0;
                                        attempts   = 0;
                                        while acceptable ~= 1 && attempts < 100

                                            theta_shocks = mvnrnd(zeros(theta_n,1), c_dsmh_allstages(i_stage-1)*(Omega_chol*Omega_chol'), 1)';
                                            theta_new_step = theta_old_allG(:,i_group) + theta_shocks;

                                                      
                                            % % % theta_new_allG(:,i_group) = theta_new_step;
                                            % % % 
                                            % % % acceptable = fun_acceptable();


                                            acceptable = fun_acceptable(theta_new_step);
                                            attempts = attempts + 1;

                                        end
                                        
                                        theta_new_allG(:,i_group) = theta_new_step;


                                        [target_function_new, logpdf_stays_new, logpdf_introduce_new, logpdf_drop_new] = fun_target_function(theta_new_allG(:,i_group), tempering_scale_thisstage,STR);

 
                                        target_function_new_allG(i_group)  = target_function_new; 
                                        logpdf_stays_new_allG(i_group)     = logpdf_stays_new;  
                                        logpdf_introduce_new_allG(i_group) = logpdf_introduce_new;
                                        logpdf_drop_new_allG(i_group)      = logpdf_drop_new;
                                        lik_log_export_new_allG(i_group)   = logpdf_introduce_new; % check

                                        prob_accept_allG = min(exp(target_function_new_allG(i_group) - target_function_old_allG(i_group)), 1); 


                                else
                                        % select striation corresponding to the last draw
                                        striation_select = 1; 
                                        for i = 2:M_dsmh                
                                            if lik_log_export_old_allG(i_group) >= logLik_levels_vec(i)
                                               striation_select = i;
                                            else
                                            end 
                                        end 
                                        i_select = unidrnd(striations_numbelements(striation_select)); 
                                        theta_new_allG(:,i_group) = striations(:,i_select,striation_select);

                                        [target_function_new, logpdf_stays_new, logpdf_introduce_new, logpdf_drop_new] = fun_target_function(theta_new_allG(:,i_group), tempering_scale_thisstage,STR);

                                        target_function_new_allG(i_group)  = target_function_new; 
                                        logpdf_stays_new_allG(i_group)     = logpdf_stays_new;  
                                        logpdf_introduce_new_allG(i_group) = logpdf_introduce_new;
                                        logpdf_drop_new_allG(i_group)      = logpdf_drop_new;
                                        lik_log_export_new_allG(i_group)   = logpdf_introduce_new; % check                

                                        prob_accept_allG = min(exp(target_function_new_allG(i_group) - target_function_old_allG(i_group)), 1); 
                                end


                              if step_udistrib_allG(i_ntau,i_group) < prob_accept_allG
                                  theta_old_allG(:,i_group)          = theta_new_allG(:,i_group);

                                  check_accepted_allG(i_group)       = check_accepted_allG(i_group)+1; 

                                  target_function_old_allG(i_group)  = target_function_new_allG(i_group);
                                  logpdf_stays_old_allG(i_group)     = logpdf_stays_new_allG(i_group);
                                  logpdf_introduce_old_allG(i_group) = logpdf_introduce_new_allG(i_group);
                                  logpdf_drop_old_allG(i_group)      = logpdf_drop_new_allG(i_group);
                                  lik_log_export_old_allG(i_group)   = lik_log_export_new_allG(i_group);
                              end 

                            % Keep only every tau-th draw
                            if intersect(i_ntau,Tau_veckeep_subloop)                        
                                
                                have_tau = have_tau + 1;
                                draw_next_temp(:,have_tau)                  = theta_old_allG(:,i_group);                    
                                logpdf_stays_next_igroup_temp(have_tau)     = logpdf_stays_old_allG(i_group);
                                logpdf_introduce_next_igroup_temp(have_tau) = logpdf_introduce_old_allG(i_group);
                                logpdf_drop_next_igroup_temp(have_tau)      = logpdf_drop_old_allG(i_group);
                                lik_log_export_next_igroup_temp(have_tau)   = lik_log_export_old_allG(i_group); 

                            end                

                        end % on i_ntau

                % Merge group-specific into aggregate output arrays --> pre-allocate
                draw_next_cell{i_group}                = draw_next_temp;    
                logpdf_stays_next_allG(:,i_group)      = logpdf_stays_next_igroup_temp;
                logpdf_introduce_next_allG(:,i_group)  = logpdf_introduce_next_igroup_temp;
                logpdf_drop_next_allG(:,i_group)       = logpdf_drop_next_igroup_temp;
                lik_log_export_next_allG(:,i_group)    = lik_log_export_next_igroup_temp;


                end % on i_group

                
                % Re-organise draw_next into array
                draw_next = NaN*ones(theta_n,N_dsmh_subloop,G_dsmh);
                for i_group = 1:G_dsmh
                    draw_next(:,:,i_group) = draw_next_cell{i_group}; % I WOULD CALL draw_next draw_next_allG
                end


                % reorganize draws
                draw_previous_subloop                    = zeros(theta_n,N_dsmh_subloop*G_dsmh);
                logpdf_stays_export_previous_subloop     = zeros(N_dsmh_subloop*G_dsmh,1);
                logpdf_introduce_export_previous_subloop = zeros(N_dsmh_subloop*G_dsmh,1);
                logpdf_drop_export_previous_subloop      = zeros(N_dsmh_subloop*G_dsmh,1);
                lik_log_export_previous_subloop          = zeros(N_dsmh_subloop*G_dsmh,1);
                for i_group = 1:G_dsmh
                    draw_previous_subloop(:,N_dsmh_subloop*(i_group-1)+1:N_dsmh_subloop*(i_group-1)+N_dsmh_subloop)                  = draw_next(:,:,i_group);
                    logpdf_stays_export_previous_subloop(N_dsmh_subloop*(i_group-1)+1:N_dsmh_subloop*(i_group-1)+N_dsmh_subloop)     = logpdf_stays_next_allG(:,i_group);
                    logpdf_introduce_export_previous_subloop(N_dsmh_subloop*(i_group-1)+1:N_dsmh_subloop*(i_group-1)+N_dsmh_subloop) = logpdf_introduce_next_allG(:,i_group);
                    logpdf_drop_export_previous_subloop(N_dsmh_subloop*(i_group-1)+1:N_dsmh_subloop*(i_group-1)+N_dsmh_subloop)      = logpdf_drop_next_allG(:,i_group);
                    lik_log_export_previous_subloop(N_dsmh_subloop*(i_group-1)+1:N_dsmh_subloop*(i_group-1)+N_dsmh_subloop)          = lik_log_export_next_allG(:,i_group);
                end 
                check_accepted_subloop = sum(check_accepted_allG);

                % if subloop > 1, augment
                draw_previous_tot                    = cat(2, draw_previous_tot,                    draw_previous_subloop);
                logpdf_stays_export_previous_tot     = cat(1, logpdf_stays_export_previous_tot,     logpdf_stays_export_previous_subloop);
                logpdf_introduce_export_previous_tot = cat(1, logpdf_introduce_export_previous_tot, logpdf_introduce_export_previous_subloop);
                logpdf_drop_export_previous_tot      = cat(1, logpdf_drop_export_previous_tot,      logpdf_drop_export_previous_subloop);
                lik_log_export_previous_tot          = cat(1, lik_log_export_previous_tot,          lik_log_export_previous_subloop);
                check_accepted_tot                   = check_accepted_tot + check_accepted_subloop;
                    
                 draw_previous                    = draw_previous_tot;
                 logpdf_stays_export_previous     = logpdf_stays_export_previous_tot;
                 logpdf_introduce_export_previous = logpdf_introduce_export_previous_tot;
                 logpdf_drop_export_previous      = logpdf_drop_export_previous_tot;
                 lik_log_export_previous          = lik_log_export_previous_tot;                 

                 accept_ratio_allstages(i_stage-1) = sum(check_accepted_tot)/(G_dsmh*N_dsmh_thisstage*Tau_dsmh_subloop);  % acceptance ratio across groups
                 
                 step1 = size(draws_allstages,2);
                 step2 = N_dsmh_thisstage*G_dsmh;
                 if step2 > step1
                      draws_allstages = cat(2, draws_allstages, NaN*ones(theta_n,step2-step1,size(draws_allstages,3)));                                                  
                 end
                 draws_allstages(:,1:step2,i_stage-1) = draw_previous;
                 
                 N_dsmh_allstages(i_stage-1)  = N_dsmh_thisstage;
                 subloop_allstages(i_stage-1) = subloop;
                 
                 subloop = subloop + 1;


    seconds_taken_compositeMH = toc(tic_compositeMH); % composite MH
    disp(['  the composite MH algorithm took (h-m-s) ', num2str(fix(mod(seconds_taken_compositeMH, [0, 3600, 60]) ./ [3600, 60, 1])) ])
    seconds_taken_compositeMHs_allstages(i_stage-1) = seconds_taken_compositeMH;
    
        
    %%% Intermediate figure for theta
    if show_indermidfig_theta == 1

        nfig = nfig + 1;
        figure(nfig)
        for i = 1:theta_n   
        
            subplot(fig_x,fig_y,i)
            hold on; grid on;
        
            legend_index = [];
            legend_names = [];
        
            %%% Plot starting distribution
            show_step = squeeze(theta_starting_draws(i,:));
            pd = fitdist(show_step','kernel'); 
            x_values = linspace(min(show_step), max(show_step), 7000);
            y = pdf(pd,x_values);
            index = plot(x_values,y, 'Linestyle', '--', 'Color', 'r', 'Linewidth', 1); hold on
        
            legend_index = [legend_index, index];
            legend_names = [legend_names; cellstr('Starting distribution')];

            %%% Plot distribution from this stage
            show_step = squeeze(draw_previous(i,:));
            pd = fitdist(show_step','kernel'); 
            x_values = linspace(min(show_step), max(show_step), 7000);
            y = pdf(pd,x_values);
            index = plot(x_values,y, 'Color', 'b', 'Linewidth', 1); hold on
        
            legend_index = [legend_index, index];
            legend_names = [legend_names; cellstr('Distribution from this stage')];

        
            %%% Additional items for the figure
            set(gca,'box','off')
            title(theta_names(i))
            set(gca, 'YTick', [0]) % eliminates ticks on y axis, since not meaningful        
        
        end
        set(gcf,'Position',figsize_1)
        movegui('west')
        set(gcf, 'PaperPositionMode', 'auto'); 

    end

    %%% Intermediate figure for diagnostics on the sampler
               
    lambda_allstages_show = lambda_allstages(isnan(lambda_allstages)==0);
    lambda_allstages_show = lambda_allstages_show(2:end); % first entry is zero by construction
    ESSrelative_allstages_show  = ESSrelative_allstages(isnan(ESSrelative_allstages)==0);
    accept_ratio_allstages_show = accept_ratio_allstages(isnan(accept_ratio_allstages)==0);

    if show_indermidfig_diagnostic == 1

        nfig = nfig+1;
        figure(nfig)   
    
            subplot(3,1,1)
            hold on; grid on; 
    
        plot([1:1:length(lambda_allstages_show)], lambda_allstages_show, '- b', 'Linewidth', 1); 
        plot([1:1:length(lambda_allstages_show)], lambda_allstages_show, '. b', 'Markersize', 10); 
        plot(i_stage-1,tempering_scale_thisstage, 'o r'); 
    
        %%% Additional items for the figure
        ylim([0 1])        
        set(gca, 'XTick', [1:1:length(lambda_allstages_show)]) % eliminates ticks on y axis, since not meaningful        
        title('tempering parameter', 'Interpreter', 'latex')
        set(gca,'box','off')
    
            subplot(3,1,2)
            hold on; grid on;
    
        plot([1:1:length(ESSrelative_allstages_show)], ESSrelative_allstages_show, '- b', 'Linewidth', 1); 
        plot([1:1:length(ESSrelative_allstages_show)], ESSrelative_allstages_show, '. b', 'Markersize', 10); 
        if isnan(H_dsmh)
            plot([1:1:length(ESSrelative_allstages_show)], ESSrelative_min*ones(length(ESSrelative_allstages_show),1), '-- r')
            plot([1:1:length(ESSrelative_allstages_show)], ESSrelative_max*ones(length(ESSrelative_allstages_show),1), '-- r')        
        end

        %%% Additional items for the figure    
        ylim([0 1])        
        set(gca, 'XTick', [1:1:length(ESSrelative_allstages_show)]) % eliminates ticks on y axis, since not meaningful        
        title('relative ESS', 'Interpreter', 'latex')
        set(gca,'box','off')
    
            subplot(3,1,3)
            hold on; grid on;
    
        plot([1:1:length(accept_ratio_allstages_show)], accept_ratio_allstages_show, '- b', 'Linewidth', 1); 
        plot([1:1:length(accept_ratio_allstages_show)], accept_ratio_allstages_show, '. b', 'Markersize', 10); 
        plot([1:1:length(accept_ratio_allstages_show)], alpha_0*ones(length(accept_ratio_allstages_show),1), '-- r')
        plot([1:1:length(accept_ratio_allstages_show)], alpha_1*ones(length(accept_ratio_allstages_show),1), '-- r')          
       
        %%% Additional items for the figure
        ylim([0 1])        
        title('acceptance ratio in composite MH', 'Interpreter', 'latex')
        set(gca, 'XTick', [1:1:length(accept_ratio_allstages_show)]) % eliminates ticks on y axis, since not meaningful        
        set(gca,'box','off')
    
        set(gcf, 'PaperPositionMode', 'auto');          
        set(gcf,'Position',[0 0 800*.7 950*.7])
        movegui('southeast')
 
    end

        
    % move on
    if tempering_scale_thisstage < 1  % Prepare for next loop
            draw_previous_pdfstay_log      = logpdf_stays_export_previous;  
            draw_previous_pdfintroduce_log = logpdf_introduce_export_previous;
            draw_previous_pdfdrop_log      = logpdf_drop_export_previous; 
            draw_previous_loglik           = lik_log_export_previous; 

            if isnan(H_dsmh) == 1       
                tempering_scale_laststage = tempering_scale_thisstage;
                [tempering_scale_thisstage, calib_tempering_iter_used, calib_tempering_diagnostics] = fun_calibrate_tempering(draw_previous_pdfintroduce_log, draw_previous_pdfdrop_log, tempering_scale_laststage, ESSrelative_min, ESSrelative_max);
                lambda_allstages(i_stage+1)             = tempering_scale_thisstage;
                lambda_diagnostics_allstages(:,1:calib_tempering_iter_used,i_stage+1) = calib_tempering_diagnostics;
            else
                tempering_scale_laststage = tempering_scale_thisstage;
                tempering_scale_thisstage = lambda_allstages(i_stage+1);                
            end
            assert( tempering_scale_thisstage > tempering_scale_laststage)        
            
            draw_previous_weights_tilde_log = (tempering_scale_thisstage - tempering_scale_laststage)*draw_previous_pdfintroduce_log + ...
                                            - (tempering_scale_thisstage - tempering_scale_laststage)*draw_previous_pdfdrop_log;        

    else % end of loop reached: save the posterior draws
         last_loop_reached = 1;
         H_dsmh_found       = i_stage-1;
         draw_posterior    = draw_previous; 

    end
            
end % along stages: i_stage

seconds_taken_DSMH = toc(tic_fullalgor); % full algorithm
disp('-')
disp(['The full algorithm took (h-m-s) ', num2str(fix(mod(seconds_taken_DSMH, [0, 3600, 60]) ./ [3600, 60, 1])) ])
         
% Summary 
if isnan(H_dsmh) == 1
    lambda_allstages             = lambda_allstages(1:H_dsmh_found+1,1); 
    lambda_diagnostics_allstages = lambda_diagnostics_allstages(:,:,1:H_dsmh_found+1);
    c_dsmh_allstages             = c_dsmh_allstages(1:H_dsmh_found,1);
    c_dsmh_allstages_iterneeded  = c_dsmh_allstages_iterneeded(1:H_dsmh_found,1);
    ESSrelative_allstages        = ESSrelative_allstages(1:H_dsmh_found,1);
    accept_ratio_allstages       = accept_ratio_allstages(1:H_dsmh_found,1);
    draws_allstages              = draws_allstages(:,:,1:H_dsmh_found);
    N_dsmh_allstages                     = N_dsmh_allstages(1:H_dsmh_found);
    seconds_taken_compositeMHs_allstages = seconds_taken_compositeMHs_allstages(1:H_dsmh_found);

end
   

%% Reorganize posterior draws into the parameters of the model

N_dsmh_laststage = N_dsmh_thisstage;

n_draws = N_dsmh*G_dsmh;
theta_ending_draws = draw_posterior; % theta_n x n_draws array

theta_intermid_draws = draws_allstages(:,:,2:end-1);
          
                    
                    
                    
                    