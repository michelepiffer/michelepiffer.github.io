%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                   %
% Routine to run the Dynamic Striated Metropolis Hastings algorithm % 
% by Waggoner_Wu_Zha (JoE 2016)                                     %
% Codes by Martin Bruns and Michele Piffer in their QE (2023) paper %
% This version: May 2026                                            %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This file: sets things up for an illustration

clc
clear
close all


%% An illustrative function 

% y=B*eps
% eps is N(0,I)
% some true B
% some entries of B possibly restricted dogmatically to a point
% on the remaining entries of B, a Normal prior 


%%% True parameter value
B_true = [2, 3; -1, 4];


%%% If run sampler on a subset of the entries of B

fun_theta_to_out = @(theta) [theta, B_true(:,2)];
theta_n = 2;
theta_names = {'B(1,1)'; 'B(2,1)'};


%%% If run sampler on all entries of B

% fun_theta_to_out = @(theta) reshape(theta,length(theta)/2,length(theta)/2);
% theta_n = 4;
% theta_names = {'B(1,1)'; 'B(2,1)'; 'B(1,2)'; 'B(2,2)'};


%%% Likelihood function of the model

T = 100;
Y = B_true*randn(2,T);
Sigma_hat = Y*Y'/T;

fun_loglik = @(B) -T*log(2*pi) - T*log(abs(det(B))) - (T/2)*trace((B*B') \ Sigma_hat);


% case_considered = 1; % Normal prior, no sign restrictions
case_considered = 2; % Normal prior, sign restrictions
% case_considered = 3; % Uniform prior, no sign restrictions

if case_considered == 1

    %%% Prior if no sign restriction. Function for a Normal prior for the free entries of B

    mu = zeros(theta_n,1);
    V  = 2*eye(theta_n);

    fun_logprior = @(theta) -0.5*(theta_n^2*log(2*pi) + log(det(V)) + (theta-mu)'/V*(theta-mu));

    theta_starting_draws = mvnrnd(mu, V, 10000)';

    fun_acceptable = @(theta) 2>1; % so that it always accept and is a logical

elseif case_considered == 2

    %%% Prior if sign restrictions 

    mu = zeros(theta_n,1);
    V  = 2*eye(theta_n);
    
    % fun_acceptable = @(theta) theta(1) > 2 && theta(2) < 0;
    fun_acceptable = @(theta) theta(2) < 0;
    
    fun_logprior = @(theta) fun_acceptable(theta)*(-0.5*(theta_n^2*log(2*pi) + log(det(V)) + (theta-mu)'/V*(theta-mu)));
    
    want = 10000;
    have = 0;
    theta_starting_draws = NaN(theta_n,want);
    while have < want
        temp = mvnrnd(mu, V, 1)';
        if fun_acceptable(temp)
            have = have + 1;
            theta_starting_draws(:,have) = temp;
        end
    end

elseif case_considered == 3

    lowB = -10;
    upB  = 10;

    fun_logprior = @(theta) 1/((upB-lowB)*theta_n);

    theta_starting_draws = lowB + (upB-lowB)*rand(theta_n,10000);

    fun_acceptable = @(theta) min(theta)>lowB && max(theta)<upB; 


end


%%% Function for the posterior for the free entries of B

fun_logpost = @(theta) fun_logprior(theta) + fun_loglik(fun_theta_to_out(theta));


%% Some checks

assert(size(theta_starting_draws,1) == theta_n, 'Initial draws were not specified for the correct number of variables')

for d = 1:size(theta_starting_draws,2)
    
    assert(fun_acceptable(theta_starting_draws(:,d)), 'Initial draw does not satisfy restrictions')

end


%% Select key inputs needed for the DSMH to run 

%%% Functions

fun_logpdf_stay      = @(theta) fun_logprior(theta)
fun_logpdf_introduce = @(theta) fun_loglik(fun_theta_to_out(theta)) 
fun_logpdf_drop      = @(theta) 0;
% fun_acceptable       = @(theta) 0;

% fun_theta_to_out


% Checking the functions
theta = randn(theta_n,1)

fun_logpdf_stay(theta)     
fun_logpdf_introduce(theta)
fun_logpdf_drop(theta)
fun_acceptable(theta)


%%% Starting draws representing "fun_logpdf_stay+fun_logpdf_drop"

assert( size(theta_starting_draws,1) == theta_n)

%%% Other items

% theta_n
% theta_names


% fig_x = 1; % x dimension of the figures
% fig_y = 2; % y dimension of the figures

fig_x = 1; % x dimension of the figures
fig_y = theta_n; % y dimension of the figures

if fig_x*fig_y <theta_n
    error('Dimensions specified for the figures is inconsistent with the dimension of theta')
end


% % % 


