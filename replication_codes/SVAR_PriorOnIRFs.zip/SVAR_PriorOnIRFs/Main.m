%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
% Small DEMO on how to use the prior on impulse responses for SVAR models
% developed by                                                         %
% Fabio Canova, Andrzej Kociecki, Michele Piffer                       %    
% "Flexible prior beliefs on impulse responses in Bayesian vector autoregressive models"
%
% June 2026                                                            %
% m.b.piffer@gmail.com                                                 %
%                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear
close all


%% Preliminary steps

%%% Colors
grey  = [0.8,0.8,0.8]; 
grey2 = [0.6,0.6,0.6];
grey3 = [0.7,0.7,0.7];
grey4 = [0.5,0.5,0.5];
blue  = [0.25,0.3,0.8];
blue2 = [0.3,0.6,0.9];
red   = [0.6,0.1,0.2];
red2  = [0.65,0.1,0.2];

%%% Size of the figure
fig_size = [0 0 1100*.7 450*.7];

%%% Add path to functions
addpath('Functions_CanKocPif')


%% Info on the DGP

%%% Number of variables
k = 2;

%%% Variables names
var_names = {'output', 'prices'};


%%% Shocks names
shock_names = {'demand shock', 'supply shock'};

%%% Horizons
p     = 12; % number of lags in the SVAR
H     = 24; % horizons up to which prior beliefs are introduced 
T_irf = 1+60; % horizon up to which IRFs are computed (impact effect + delayed response)

T_irf_axis = [0:1:T_irf-1]';

%%% Size of the simulated
shock_size = 1; % consistent with normalizing variance of the structural shocks to 1

%%% Number of prior draws
n_prior  = 5000;

%%% Figur counter
nfig = 0;

%%% Pseudo scaling factors usually (comptued on training sample)
sigma_univariate_ols = 0.5*ones(k,1);


%% Save B_mean, the expected value of the impact effect

priorB_draws = NaN(k,k,n_prior); 

% prior_impacteffect = '1) prior on B, no sign restrictions on impact';
prior_impacteffect = '2) prior on B reflecting sign restrictions on impact';
% prior_impacteffect = '3) prior on Sigma, then Cholesky';
% prior_impacteffect = '4) prior on (Sigma,Q), then sign restrictions on impact via accept reject';

if strcmp(prior_impacteffect,'1) prior on B, no sign restrictions on impact')

    temp_mean = [0.5; 0.3; -0.8; 0.5]; 
    temp_var  = diag([0.08, 0.08, 0.08, 0.08]); 

    B_mean = reshape(temp_mean,k,k);

    temp_priordraws_vecB = temp_mean + chol(temp_var)'*sqrt(shock_size)*randn(k^2,n_prior);
    priorB_draws   = reshape(temp_priordraws_vecB,k,k,n_prior);

elseif strcmp(prior_impacteffect,'2) prior on B reflecting sign restrictions on impact')

    fun_accept_impacteffect = @(vecB) vecB(1)>0 && vecB(2)>0 && vecB(3)<0 && vecB(4)>0;

    temp_mean = [0.5; 0.3; -0.8; 0.5]; 
    temp_var  = diag([0.08, 0.08, 0.08, 0.08]); 

    assert(fun_accept_impacteffect(temp_mean))

    have = 0;
    while have < n_prior
        temp_priordraws_vecB = temp_mean + chol(temp_var)'*sqrt(shock_size)*randn(k^2,1);
        if fun_accept_impacteffect(temp_priordraws_vecB)
            have = have + 1;
            priorB_draws(:,:,have) = reshape(temp_priordraws_vecB,k,k);
        end
    end

    B_mean = mean(priorB_draws,3);

elseif strcmp(prior_impacteffect,'3) prior on Sigma, then Cholesky')

    prior_Sigma_calib    = 'Kadiyala and Karlsson';
    [df_prior, S_prior, DI_S_prior] = fun_InverseWishart_calib(prior_Sigma_calib,k,sigma_univariate_ols);

    for i_sim = 1:n_prior 
        temp_Sigma = fun_draw_inverseWishart(S_prior,df_prior,DI_S_prior);
        priorB_draws(:,:,i_sim) = chol(temp_Sigma)';
    end

    B_mean = mean(priorB_draws,3);

elseif strcmp(prior_impacteffect,'4) prior on (Sigma,Q), then sign restrictions on impact via accept reject')

    prior_Sigma_calib    = 'Kadiyala and Karlsson';
    [df_prior, S_prior, DI_S_prior] = fun_InverseWishart_calib(prior_Sigma_calib,k,sigma_univariate_ols);

    fun_accept_impacteffect = @(vecB) vecB(1)>0 && vecB(2)>0 && vecB(3)<0 && vecB(4)>0;

    have = 0;
    while have < n_prior
        temp_Sigma = fun_draw_inverseWishart(S_prior,df_prior,DI_S_prior);
        temp_Q     =  fun_orthogmatrix_RWZ(k);
        temp_B     = chol(temp_Sigma)'*temp_Q;
        if fun_accept_impacteffect(temp_B(:))
            have = have + 1;
            priorB_draws(:,:,have) = temp_B;
        end
    end

    B_mean = mean(priorB_draws,3);

else
    error('Prior on impact effect not specified')
end


%% Starting from B_mean, set the intended shape of the IRFs up to horizon H

Psi_bar = NaN*ones(k,k,1+H); % intended mean of the IRFs


prior_IRFshapes = '1) via Gaussian basis function';
% prior_IRFshapes = '2) [other method]';

if strcmp(prior_IRFshapes, '1) via Gaussian basis function')

    %%% Impact effect is the expected value of B
    param_a = B_mean; 
        
    %%% Timing after peak effect is shock/variable specific
    param_b = NaN(k,k);
    param_hl = NaN(k,k);
    param_pf = NaN(k,k);

    %%% Select how persistence is set for cases when b>0, hence peak response is not on impact
    Option_c = 'control_peak_effect';
    % Option_c = 'control_half_life';  

    j = find(strcmp(shock_names, 'demand shock'));

        i = find(strcmp(var_names, 'output'));
        param_b(i,j)  = 0;
        param_hl(i,j) = 5;

        i = find(strcmp(var_names, 'prices'));
        param_b(i,j)  = 0;
        param_hl(i,j) = 7;


    j = find(strcmp(shock_names, 'supply shock'));

        i = find(strcmp(var_names, 'output'));
        param_b(i,j)  = 5;
        param_pf(i,j) = 2.5;

        i = find(strcmp(var_names, 'prices'));
        param_b(i,j)  = 5;
        param_pf(i,j) = 2;


    %%% Compute parameter c that implies (param_hl, param_pf)  
    param_c = fun_param_c(param_a, param_b, param_hl, param_pf, Option_c);

    %%% Compute IRFs by Gaussian basis function
    Psi_bar = fun_Psi_bar(H, param_a, param_b, param_c);


elseif strcmp(prior_IRFshapes, '2) [other method]') 

    % Add here

end

%%% Use CanKocPif to compute the mean of Pi associated with Psi_bar
[mu_Pi_lags, ~] = fun_prior_CanKocPiff(Psi_bar,p);
mu_phi          = reshape(mu_Pi_lags, k*k*p, 1);


%%% Check that Psi_bar does not lead to a non-stationary SVAR
[maxroot, maxroot_isreal] = fun_maxroot_stationarity(mu_Pi_lags);
assert(maxroot<1, 'Selected B mean and Psi bar imply a non stationary VAR. Change selection')


%% Draw from the prior

%%% Specify type of prior
% prior_phi = 'independent'; % (Pi,B) prior independent
prior_phi = 'conjugate'; % prior variance of Pi features Sigma=BB' via Kroeneker product


%%% Select prior tightness
% lambda1 = 0.0008;
% lambda1_interpret = {'1) lambda1 is the variance'}; % textbook by F. Canova

lambda1 = 0.03;
lambda1_interpret = {'2) lambda1 is the standard deviation'}; % Banbura, Giannone, Reichlin
[V_phi, V_phi_small] = fun_MinnesotaPrior_variance_lagsonly(lambda1, prior_phi, sigma_univariate_ols, p, lambda1_interpret);


%%% Select prior moments
mu_phi_use = reshape(mu_Pi_lags, k*k*p, 1);
if strcmp(prior_phi, 'independent') 
    V_phi_use  = V_phi;
end

%%% Draw 
priorIRFs_draws       = NaN*ones(k,T_irf,k,n_prior);
priorIRFs_Bonly_draws = NaN*ones(k,T_irf,k,n_prior);
for i_sim = 1:n_prior

    %%% Select prior draw of B
    temp_B = priorB_draws(:,:,i_sim);
    
    %%% If conjugate prior, compute variance of phi
    if strcmp(prior_phi, 'conjugate') 
        V_phi_use = kron(V_phi_small, temp_B*temp_B');
    end

    %%% Draw Pi
    temp_phi = fun_draw_multivNormal(mu_phi_use,V_phi_use);
    temp_Pi_lags   = reshape(temp_phi, k, k*p);

    %%% Compute IRFs
    temp_IRFs = NaN*ones(k,T_irf,k);
    for j = 1:k 
        temp_IRFs(:,:,j) = fun_IRFs(temp_Pi_lags, temp_B, T_irf, j, 1);
    end
    priorIRFs_draws(:,:,:,i_sim) = temp_IRFs;

    %%% Only with prior uncertanty from B
    temp_IRFs = NaN*ones(k,T_irf,k);
    for j = 1:k 
        temp_IRFs(:,:,j) = fun_IRFs(reshape(mu_phi_use, k, k*p), temp_B, T_irf, j, 1);
    end
    priorIRFs_Bonly_draws(:,:,:,i_sim) = temp_IRFs;
    
    %%% Check progression 
    fun_checkprogression(i_sim,n_prior)            

end

[priorIRFs_mean,        priorIRFs_median,        priorIRFs_bands68,        priorIRFs_bands90,        priorIRFs_bands95] = fun_summary_percentiles2(priorIRFs_draws, 4);
[priorIRFs_Bonly_mean,  priorIRFs_Bonly_median,  priorIRFs_Bonly_bands68,  priorIRFs_Bonly_bands90,  priorIRFs_Bonly_bands95]  = fun_summary_percentiles2(priorIRFs_Bonly_draws, 4);


%% If use a conjugate specification, compute the dummy observations that can be used instead of the actual prior

if strcmp(prior_phi, 'conjugate') 

    [Y_star, X_star, T_star] = fun_conjugateprior_to_dummyobs(mu_phi, V_phi_small, k, p);

end

%% Figures

T_irf_show = 40; % if plot only up to a certain horizon
assert(T_irf_show <= T_irf)


nfig = nfig + 1;
figure(nfig)
for i = 1:k
    for j = 1:k

       subplot(k,k,(i-1)*k + j)
       grid on; hold on;

       %%% Specify empty entries for the legend
       legend_index = [];
       legend_names = [];

       %%% Plot zero line
       yline(0, 'Color', grey2)
       
       %%% Plot individual prior draws of the IRFs
       temp_h = T_irf;
       for ddd = 1:10
           % plot(T_irf_axis, squeeze(priorIRFs_draws(i,:,j,ddd)), '- k', 'Linewidth', 0.5); 
           % plot(T_irf_axis, squeeze(priorIRFs_Bonly_draws(i,:,j,ddd)), '- k', 'Linewidth', 0.5); 
           % plot(T_irf_axis, squeeze(priorIRFs_Pionly_draws(i,:,j,ddd)), '- k', 'Linewidth', 0.5); 
       end

       
       %%% Prior on the IRFs: bands
       index = fill([T_irf_axis',fliplr(T_irf_axis')],[squeeze(priorIRFs_bands68(i,:,j,2)), ...
                                                  fliplr(squeeze(priorIRFs_bands68(i,:,j,1)))], ...
                                                  blue,'EdgeColor','none', 'FaceAlpha', 0.5);                     
       index = fill([T_irf_axis',fliplr(T_irf_axis')],[squeeze(priorIRFs_bands90(i,:,j,2)), ...
                                                  fliplr(squeeze(priorIRFs_bands90(i,:,j,1)))], ...
                                                  blue2,'EdgeColor','none', 'FaceAlpha', 0.5);   
       legend_index = [legend_index, index];
       legend_names = [legend_names; cellstr('$68\%/90\%$ sets')]; 


       %%% Prior on the IRFs: bands, when setting V=0 (only uncertainty from B)
       index = plot(T_irf_axis, squeeze(priorIRFs_Bonly_bands68(i,:,j,2)), '--', 'Color', 'k', 'Linewidth', 1); 
       index = plot(T_irf_axis, squeeze(priorIRFs_Bonly_bands68(i,:,j,1)), '--', 'Color', 'k', 'Linewidth', 1); 
       index = plot(T_irf_axis, squeeze(priorIRFs_Bonly_bands90(i,:,j,2)), '--', 'Color', 'k', 'Linewidth', 1); 
       index = plot(T_irf_axis, squeeze(priorIRFs_Bonly_bands90(i,:,j,1)), '--', 'Color', 'k', 'Linewidth', 1); 
       legend_index = [legend_index, index];
       legend_names = [legend_names; cellstr('$68\%/90\%$ sets for $V=0$')]; 


       %%% Plot Psi_bar
       index = plot(T_irf_axis(1:1:H+1), squeeze(Psi_bar(i,j,:)), 'o- k', 'Linewidth', 1, 'Markersize', 6); 
       legend_index = [legend_index, index];
       legend_names = [legend_names; cellstr('Intended mean ($\bar{\Psi}$)')];


       %%% Prior on the IRFs: median
       % index = plot(T_irf_axis, priorIRFs_median(i,:,j), '--', 'Color', red2); 
       % legend_index = [legend_index, index];
       % legend_names = [legend_names; cellstr('Implied median')]; 


       %%% Prior on the IRFs: mean
       % index = plot(T_irf_axis, priorIRFs_mean(i,:,j),     '.', 'Markersize', 8, 'Color', red2); 
       % legend_index = [legend_index, index];
       % legend_names = [legend_names; cellstr('Implied mean')]; 


       %%% Additional items for the figure 
       xlim([0 T_irf_show])
       % set(gca, 'XTick', [2:2:H+1]) 
       set(gca,'box','off')

        if i == 1 
            title(shock_names(j), 'Interpreter','latex')
        end
        if j == 1
            ylabel(var_names(i), 'Interpreter','latex')
        end
        if i == 2 
            xlabel('Impulse response horizon', 'Interpreter','latex')
        end
    end
end
lgd = legend(legend_index, legend_names, 'Interpreter', 'latex', 'AutoUpdate', 'off'); % legend('boxoff') 
set(lgd, 'Orientation', 'horizontal');
set(lgd, 'Position', [0.4, 0, 0.2, 0.05]);  % [x y width height]

set(gcf,'Position', fig_size) 

movegui('west')
set(gcf, 'PaperPositionMode', 'auto');

