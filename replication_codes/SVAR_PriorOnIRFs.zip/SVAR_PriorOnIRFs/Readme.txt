--------------------------------------------------------------------------------------------------------------------
This folder contains a demo on how to use the prior on impulse responses developed by 

Canova, Kociecki and Piffer  
"Flexible prior beliefs on impulse responses in Bayesian vector autoregressive models"


The prior is about how to set the mean of the Normal prior on the reduced form autoregressive parameters of a SVAR, given some prior mean on the impact effect of the shocks. The demo considers different priors for the impact effect of the shocks, including the popular inverse Wishart prior for sign restrictions.

The prior can be specified as an independent prior or a conjugate prior. For the latter case, the code computes dummy observations

The prior requires selecting Psi_bar, which is the intended prior mean. The code and the paper use a Gaussian basis function to set Psi_bar. Other methods are possible. The contribution of the paper is to derive the first prior moment of the autoregressive parameters, given a pre-selected Psi_bar

The prior variance of the autoregressive parameters must be selected carefully

--------------------------------------------------------------------------------------------------------------------

Michele Piffer
24/6/2026
m.b.piffer@gmail.com

--------------------------------------------------------------------------------------------------------------------