function [df_prior, S_prior, DI_S_prior] = fun_InverseWishart_calib(prior_Sigma_calib,k,sigma_univariate_ols)

if strcmp(prior_Sigma_calib, 'Flat')

    df_prior = 0;             
    S_prior  = 0*eye(k);
    DI_S_prior = chol(inv(S_prior));

elseif strcmp(prior_Sigma_calib, 'Kadiyala and Karlsson') 

    df_prior = k+2;    
    S_prior  = (df_prior-k-1)*diag(sigma_univariate_ols.^2);
    DI_S_prior = chol(inv(S_prior));

end

end