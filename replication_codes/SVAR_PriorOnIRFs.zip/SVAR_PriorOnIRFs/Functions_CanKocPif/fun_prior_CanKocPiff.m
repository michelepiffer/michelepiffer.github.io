function [Pi_lags, B] = fun_prior_CanKocPiff(Psi_bar,p)

    k = size(Psi_bar,1);
    H = size(Psi_bar,3)-1;

    % R matrices evaluated for Psi=Psi_bar
    [R_small_bar, R_bar, Riota_small_bar, Riota_bar] = fun_Rmatrices_full(Psi_bar,k,p);
    
    % psi_bar vectors
    [psi_bar, psi_bar0, psi_barF] = fun_psi_vectors(Psi_bar,k);
    
    
    % Compute entire IRF associated with Psi_bar
    B  = reshape(psi_bar0,k,k);
    if H == p
        pi_lags = Riota_bar*psi_barF;
    else
    %     pi_true = inv(R_bar'*R_bar)*R_bar'*psi_barF;
        pi_lags = (R_bar'*R_bar)\R_bar'*psi_barF;
    end
    assert( sum(isnan(pi_lags)) == 0 )
    
    Pi_lags = reshape(pi_lags,k,k*p);


    assert(size(Pi_lags,1) == k)
    assert(size(Pi_lags,2) == k*p)



end