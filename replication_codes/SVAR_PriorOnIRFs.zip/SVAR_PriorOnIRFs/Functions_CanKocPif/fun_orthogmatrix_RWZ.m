function Q = fun_orthogmatrix_RWZ(n)

X = randn(n,n);
[Q, R] = qr(X); 

Rdiag = diag(R);
step = sign(Rdiag);
Q = Q*diag(step);
R = diag(step)*R;

assert(max(max(abs(X - Q*R))) < 0.0001 )
assert(max(max(Q'*Q- eye(n))) < 0.001)   
assert(max(max(Q*Q'- eye(n))) < 0.001)   

Rdiag = diag(R);
assert(min(Rdiag) > 0)

end