function [Y_star, X_star, T_star] = fun_conjugateprior_to_dummyobs(mu_phi, V_phi_small, k, p)
% FUN_DUMMY_CONJUGATE  Dummy observations encoding the conjugate Minnesota prior
%
% The conjugate prior vec(Pi) | B ~ N(mu_phi, kron(V_phi_small, B*B')) is
% represented as kp fictitious observations (Y_star, X_star) such that OLS
% on the augmented system [Y_star; Y], [X_star; X] with residual covariance
% B*B' reproduces the posterior implied by the prior.
%
% Note: B*B' does not appear here explicitly. It enters as the cross-equation
% residual covariance when running GLS on the augmented system.
%
% INPUTS
%   mu_phi      (k^2*p x 1)  vectorised prior mean of Pi, i.e. vec(M)
%   V_phi_small (k*p x k*p)  column covariance from Minnesota prior
%   k           scalar        number of variables
%   p           scalar        number of lags
%
% OUTPUTS
%   Y_star      (k*p x k)    dummy dependent variable
%   X_star      (k*p x k*p)  dummy regressors
%
% DERIVATION
%   We want X_star such that (X_star'*X_star)^{-1} = V_phi_small
%   => X_star'*X_star = inv(V_phi_small)
%   => X_star = inv(chol(V_phi_small))'       [lower triangular, kp x kp]
%
%   The dummy LHS is then:
%   Y_star = X_star * M'                      [kp x k]
%
%   so that OLS on dummies alone gives:
%   Pi_hat' = (X_star'*X_star)^{-1} * X_star'*Y_star = V_phi_small * inv(V_phi_small) * M' = M'

%% Input checks
assert(numel(mu_phi)          == k^2*p,      'mu_phi must be k^2*p x 1')
assert(isequal(size(V_phi_small), [k*p k*p]),'V_phi_small must be k*p x k*p')

%% Reshape prior mean
M = reshape(mu_phi, k, k*p);          % (k x kp)

%% Cholesky factorisation of V_phi_small
% V_phi_small = chol_V' * chol_V  (chol_V upper triangular)
% X_star = inv(chol_V)'           (lower triangular, kp x kp)
chol_V = chol(V_phi_small);           % (kp x kp) upper triangular
X_star = inv(chol_V)';               % (kp x kp)

%% Dummy LHS
Y_star = X_star * M';                 % (kp x k)

T_star = size(Y_star,1);


%% Sanity checks
tol = 1e-6;
assert(norm(X_star'*X_star * V_phi_small - eye(k*p), 'fro') < tol, ...
    'X_star does not reproduce prior precision inv(V_phi_small)')
assert(norm(V_phi_small * (X_star'*Y_star) - M', 'fro') < tol, ...
    'OLS on dummies does not recover prior mean M')

assert(T_star==k*p)


%% How to use it

%%% Without dummy observations

% X is    % T x kp
% Y is    % T x k


%%% With dummy observations

% X_augmented = [X_star; X]    % (kp + T) x kp
% Y_augmented = [Y_star; Y]    % (kp + T) x k


end