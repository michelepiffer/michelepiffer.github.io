function fun_checkprogression(have,want)


    if have == floor((want)*(1-0.80))+1
           disp('  80% still to go')
    elseif have == floor((want)*(1-0.6))+1
           disp('  60% still to go')
    elseif have == floor((want)*(1-0.4))+1
           disp('  40% still to go')
    elseif have == floor((want)*(1-0.2))+1
           disp('  20% still to go')
    end 


end