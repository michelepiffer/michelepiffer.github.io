function Sigma = fun_draw_inverseWishart(S0,df0,DI_S0)

    % Sigma = iwishrnd(S0,df0); % equivalent to "wishrnd(inv(S0),df0)"
    Sigma = iwishrnd(S0,df0,DI_S0); % if generate multiple draws , more efficient to specify DI as well

end
