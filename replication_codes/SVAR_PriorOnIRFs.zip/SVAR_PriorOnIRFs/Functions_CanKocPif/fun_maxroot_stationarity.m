function [maxroot, maxroot_isreal] = fun_maxroot_stationarity(Pi_lags)

    % Pi_lags is only the autoregressive part
    k = size(Pi_lags,1);
    p = size(Pi_lags,2)/k;
    
    companion = [Pi_lags; kron(eye(p-1,p-1),eye(k)),zeros(k*(p-1),k)];
    [~, C]    = eig(companion);
    eig_all   = flip(sort(diag(abs(C))));
    if p > 0
        maxroot = eig_all(1);
    else
        maxroot = 0;
    end
    
    maxroot_isreal = isreal(maxroot);
                                        
end
                                        
                                        