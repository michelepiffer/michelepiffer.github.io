function [out_mean, out_median, out_bands68, out_bands90, out_bands95] = fun_summary_percentiles2(in_draws, dim)

% FUN_SUMMARY_PERCENTILES  Compute mean and percentile bands along any dimension.
%
%   INPUT
%     in_draws : array of arbitrary shape, e.g. N1 x N2 x N3 x M
%     dim      : dimension along which to compute statistics (e.g. 4)
%
%   OUTPUT
%     out_mean    : same shape as in_draws with 'dim' collapsed to size 1
%     out_median  : same
%     out_bands68 : same but 'dim' has size 2  [lower, upper]  (68% band)
%     out_bands90 : same but 'dim' has size 2  (90% band)
%     out_bands95 : same but 'dim' has size 2  (95% band)

    interval_68 = 32;
    interval_90 = 10;
    interval_95 =  5;

    out_mean   = mean(in_draws, dim);
    out_median = prctile(in_draws, 50, dim);

    out_bands68 = cat(dim, prctile(in_draws,       interval_68/2, dim), ...
                           prctile(in_draws, 100 - interval_68/2, dim));
    out_bands90 = cat(dim, prctile(in_draws,       interval_90/2, dim), ...
                           prctile(in_draws, 100 - interval_90/2, dim));
    out_bands95 = cat(dim, prctile(in_draws,       interval_95/2, dim), ...
                           prctile(in_draws, 100 - interval_95/2, dim));

end



