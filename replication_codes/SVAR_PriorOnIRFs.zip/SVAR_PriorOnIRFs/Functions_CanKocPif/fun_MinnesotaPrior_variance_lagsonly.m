function [V_phi_Minn, V_phi_small_Minn] = fun_MinnesotaPrior_variance_lagsonly(lambda1, prior_phi, sigma_univariate_ols, p, lambda1_interpret)

k = length(sigma_univariate_ols);


%%% Hyperparameter values

% lambda1 = 0.2;  % 0.2  RATS Manual/Canova      controls the standard deviation of the prior on own lags. phi0 in Canova
lambda2 = 0.5;  % 0.5  RATS Manual/Canova      controls the standard deviation of the prior on lags of variables other than the dependent variable. phi1 in Canova. Needed only for the independent prior specification
lambda3 = 2;    % 1 or 2 RATS Manual/Canova. banuburaGainReich use 2   controls the degree to which coefficients on lags higher than 1 are likely to be zero.
lambda4 = 1e5;  % 1e5  RATS Manual/Canova        controls the prior variance on the constant. 


%%% Select if lambda1 is interpreted as variance or standard deviation
if strcmp(lambda1_interpret, '1) lambda1 is the variance')
    lambda1_variance = lambda1;

elseif strcmp(lambda1_interpret, '2) lambda1 is the standard deviation')
    lambda1_variance = lambda1^2;

else
    error('interpretation of lmabda1 not specified')
end


if  strcmp(prior_phi, 'independent') 

    %%% Prior on pi is independent on Sigma or B 
    func_minnes_variance = @(i,j,lag) ( lambda1_variance/(lag^lambda3) * lambda2^(i-j~=0))^1 * (sigma_univariate_ols(i)/sigma_univariate_ols(j))^2; % this function: in equation featuring variable "i", gives variance of variable "j" at lag "lag"
    
    variances_Pi_Minn = NaN(k,k*p);
    for row = 1:k 
        for col = 1:k*p
            i = row;
            lag = ceil(col/k);
            j = col - (lag-1)*k;
            variances_Pi_Minn(row,col)  = func_minnes_variance(i,j,lag);   
        end
    end

    V_phi_Minn = diag(reshape(variances_Pi_Minn,k*k*p,1));
    V_phi_small_Minn = NaN;

elseif strcmp(prior_phi, 'conjugate')

       %%% Prior on pi is conjugate, hence depends on Sigma or B 
       func_minnes_variance = @(i,j,lag) ( lambda1_variance/(lag^lambda3) * lambda2^(i-j~=0))^1 * (sigma_univariate_ols(i)/sigma_univariate_ols(j))^2; % this function: in equation featuring variable "i", gives variance of variable "j" at lag "lag"

       V_phi_small_Minn = zeros(k*p, k*p);
        
       for col = 1:k*p
            lag = ceil(col/k);
            j   = col - (lag-1)*k;
            % For the conjugate case, variances do NOT depend on the equation index i
            % because cross-equation covariance is handled by Σ ⊗ V_phi_small_Minn.
            V_phi_small_Minn(col,col) = func_minnes_variance(1, j, lag);
       end
      
       V_phi_Minn = NaN;

else
    StopCodeHere

end

% NB. Textbook by Fabio Canova parametrizes the variance in phi_can = lambda, while
% Banbura, Giannone,Reichlin (JAE 2010) parametrizes it in phi_bgr =
% lambda^2. Calibration in BGR is 
% phi_bgr = [0.262 (CEE model, 7 variables), 0.108 (Medium model, 20 variables), 0.035 (large model, 131 variables)],
% which corresponds to
% phi_can = [0.0686, 0.0117, 0.0012]
% for instance calibrating phi_can=0.001 is equivalent to phi_bgr = 0.0316,


end