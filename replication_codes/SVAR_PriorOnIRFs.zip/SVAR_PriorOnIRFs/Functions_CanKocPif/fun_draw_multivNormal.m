function draw = fun_draw_multivNormal(mu,V)

   step = chol(V)';
   draw = mvnrnd(mu,step*step', 1)' ;

end
