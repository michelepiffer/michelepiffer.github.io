function out = fun_GaussBasis(h, param_GaussBasis, type_GaussBasis) 


    if strcmp(type_GaussBasis, 'Original FAIR type')

        a = param_GaussBasis(1);
        b = param_GaussBasis(2);
        c = param_GaussBasis(3);

        assert(b >= 0) 
    
        % a is maximum value, and it is reached at b. Half of the maximum
        % effect is reached at period b+c*sqrt(log(2))
        out = a*exp( -(h-b)^2/c^2 );

    elseif strcmp(type_GaussBasis, 'Adjusted 1')

        a = param_GaussBasis(1); % impact effect
        b = param_GaussBasis(2); % horizon at which peak effect is reached
        c = param_GaussBasis(3); %

        assert(b >= 0) 
        
        out = a*exp(b^2/c^2)*exp( -(h-b).^2./c^2 );
        
        % a = impact effect. 
        % out(h=0) = a  

        % b = horizon at which peak is reached
        % out(h=b) = a exp(b^2/c^2)

        % c positively correlates with the persistence of the effect. Can
        % calibrate c in different ways, for instance so that after the
        % peak effect (be it at o or a b>0) the half-life of the effect is
        % reached a certain number of periods of interest

        % if a=0, then full function equals zero for any b,c

        % function is symmetric around b, i.e. for b>0
        % out(h=0) = out(h=2b) = a

    else
        StopCodeHere
    end

end
